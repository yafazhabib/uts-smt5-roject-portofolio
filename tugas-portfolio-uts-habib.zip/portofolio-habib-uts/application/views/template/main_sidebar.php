<div class="col-md-4">
    <!-- Iklan Satu -->
        <div class="card my-4">
        <h5 class="card-header">Berita Baru</h5>
            <div class="card-body">
                <div>
                    <img class="img-fluid" src="assets/images/Consulting.png" alt="alternative">
                </div>
            </div>
        </div>
    <!-- Iklan Satu -->
        <div class="card my-4">
        <h5 class="card-header">Berita Baru</h5>
            <div class="card-body">
                <div>
                    <img class="img-fluid" src="assets/images/Consulting.png" alt="alternative">
                </div>
            </div>
        </div>

    <!-- Iklan Dua -->
        <div class="card my-4">
        <h5 class="card-header">Berita Baru</h5>
            <div class="card-body">
                <div>
                    <img class="img-fluid" src="assets/images/Consulting.png" alt="alternative">
                </div>
            </div>
        </div>
</div>
