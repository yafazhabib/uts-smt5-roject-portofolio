 <!-- Footer -->
 <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="footer-col">
                        <h4 style="color:#fff;">
						</h4>
                        <img class="center" style="border-radius: 15px 15px 15px 15px;" src="<?= base_url('front-end/')?>assets/images/blackexpo.png">
                        <br>
                    </div>
                </div> <!-- end of col -->
                <div class="col-md-4">
                    <div class="footer-col last">
                        <h4 style="color:#fff; text-align: center;"></h4>
                    </div> 
                </div> <!-- end of col -->
                <div class="col-md-4">
                    <div class="footer-col last">
                    <iframe src=
                 <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of footer -->  
    <!-- end of footer -->


    <!-- Copyright -->
    <div class="copyright">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="p-small" style="color:#fff;">Copyright 2021 Cyber Teknologi Putrawan</p>
                </div> <!-- end of col -->
            </div> <!-- enf of row -->
        </div> <!-- end of container -->
    </div> <!-- end of copyright --> 
    <!-- end of copyright -->
  