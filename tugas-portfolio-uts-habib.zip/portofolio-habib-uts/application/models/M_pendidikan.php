<?php
class M_pendidikan extends CI_Model{

	function get_karakofolio_home(){
		$hsl=$this->db->query("SELECT tbl_pendidikan.*,DATE_FORMAT(pend_tanggal,'%d %M %Y') AS tanggal FROM tbl_pendidikan ORDER BY pend_id DESC limit 8");
		return $hsl;
	}

	function get_all_pendidikan(){
		$hsl=$this->db->query("SELECT tbl_pendidikan.*,DATE_FORMAT(pend_tanggal,'%d %M %Y') AS tanggal FROM tbl_pendidikan ORDER BY pend_id DESC");
		return $hsl;
	} 
	
	function simpan_pendidikan($judul,$isi,$user_nama,$gambar){
		$hsl=$this->db->query("INSERT INTO tbl_pendidikan (pend_judul,pend_deskripsi,pend_author,pend_image) VALUES ('$judul','$isi','$user_nama','$gambar')");
		return $hsl;
	}

	function get_pendidikan_by_kode($kode){
		$hsl=$this->db->query("SELECT * FROM tbl_pendidikan WHERE pend_id='$kode'");
		return $hsl;
	}

	function update_pendidikan($pend_id,$judul,$isi,$user_nama,$gambar){
		$hsl=$this->db->query("UPDATE tbl_pendidikan SET pend_judul='$judul',pend_deskripsi='$isi',pend_author='$user_nama',pend_image='$gambar' WHERE pend_id='$pend_id'");
		return $hsl;
	}

	function update_pendidikan_tanpa_img($pend_id,$judul,$isi,$user_nama){
		$hsl=$this->db->query("UPDATE tbl_pendidikan SET pend_judul='$judul',pend_deskripsi='$isi',pend_author='$user_nama' WHERE pend_id='$pend_id'");
		return $hsl;
	}

	function hapus_pendidikan($kode){
		$hsl=$this->db->query("DELETE FROM tbl_pendidikan WHERE pend_id='$kode'");
		return $hsl;
	}


	//Frontend
	function get_pendidikan(){
		$hsl=$this->db->query("SELECT tbl_pendidikan.*,DATE_FORMAT(pend_tanggal,'%d %M %Y') AS tanggal FROM tbl_pendidikan ORDER BY pend_id DESC");
		return $hsl;
	}

	function get_pendidikan_per_page($offset,$limit){
		$hsl=$this->db->query("SELECT tbl_pendidikan.*,DATE_FORMAT(pend_tanggal,'%d %M %Y') AS tanggal FROM tbl_pendidikan ORDER BY pend_id DESC LIMIT $offset,$limit");
		return $hsl;
	}
}