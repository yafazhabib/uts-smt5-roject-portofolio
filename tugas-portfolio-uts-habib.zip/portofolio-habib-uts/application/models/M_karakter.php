<?php
class M_karakter extends CI_Model{

	function get_karakofolio_home(){
		$hsl=$this->db->query("SELECT tbl_karakter.*,DATE_FORMAT(karak_tanggal,'%d %M %Y') AS tanggal FROM tbl_karakter ORDER BY karak_id DESC limit 8");
		return $hsl;
	}

	function get_all_karakter(){
		$hsl=$this->db->query("SELECT tbl_karakter.*,DATE_FORMAT(karak_tanggal,'%d %M %Y') AS tanggal FROM tbl_karakter ORDER BY karak_id DESC");
		return $hsl;
	} 
	
	function simpan_karakter($judul,$isi,$user_nama,$gambar){
		$hsl=$this->db->query("INSERT INTO tbl_karakter (karak_judul,karak_deskripsi,karak_author,karak_image) VALUES ('$judul','$isi','$user_nama','$gambar')");
		return $hsl;
	}

	function get_karakter_by_kode($kode){
		$hsl=$this->db->query("SELECT * FROM tbl_karakter WHERE karak_id='$kode'");
		return $hsl;
	}

	function update_karakter($karak_id,$judul,$isi,$user_nama,$gambar){
		$hsl=$this->db->query("UPDATE tbl_karakter SET karak_judul='$judul',karak_deskripsi='$isi',karak_author='$user_nama',karak_image='$gambar' WHERE karak_id='$karak_id'");
		return $hsl;
	}

	function update_karakter_tanpa_img($karak_id,$judul,$isi,$user_nama){
		$hsl=$this->db->query("UPDATE tbl_karakter SET karak_judul='$judul',karak_deskripsi='$isi',karak_author='$user_nama' WHERE karak_id='$karak_id'");
		return $hsl;
	}

	function hapus_karakter($kode){
		$hsl=$this->db->query("DELETE FROM tbl_karakter WHERE karak_id='$kode'");
		return $hsl;
	}


	//Frontend
	function get_karakter(){
		$hsl=$this->db->query("SELECT tbl_karakter.*,DATE_FORMAT(karak_tanggal,'%d %M %Y') AS tanggal FROM tbl_karakter ORDER BY karak_id DESC");
		return $hsl;
	}

	function get_karakter_per_page($offset,$limit){
		$hsl=$this->db->query("SELECT tbl_karakter.*,DATE_FORMAT(karak_tanggal,'%d %M %Y') AS tanggal FROM tbl_karakter ORDER BY karak_id DESC LIMIT $offset,$limit");
		return $hsl;
	}
}