<br>
<br>
<br>
<br>
<br>
<!-- Card About -->
<div class="basic-2">
        <div class="container">
          <div class="row">
          <?php
          	$no=0;
          	foreach ($data->result_array() as $i) :
          	$no++;
          	$pend_id=$i['pend_id'];
          	$pend_judul=$i['pend_judul'];
          	$pend_isi=$i['pend_deskripsi'];
          	$pend_tanggal=$i['tanggal'];
          	$pend_author=$i['pend_author'];
          	$pend_gambar=$i['pend_image'];        
          ?>
            <div class="col-lg-6">
                    <div class="image-container">
                        <img class="img-fluid" src="<?php echo base_url().'assetsadm/images/'.$pend_gambar;?>" alt="alternative">
                    </div> <!-- end of image-container -->
            </div> <!-- end of col -->
            <div class="col-lg-6">
                    <div class="text-container">
                        <h2 style="color:#FF6647;">Pendidikan Saya</h2>
                        <p style="color: #000;"><?php echo $pend_isi;?></p>
                        
                    </div> <!-- end of text-container -->
            </div> <!-- end of col -->
            <?php endforeach;?>
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of basic-2 -->

    <!-- Scripts -->
    <script src="<?= base_url('front-end/');?>assets/js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
    <script src="<?= base_url('front-end/');?>assets/js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
    <script src="<?= base_url('front-end/');?>assets/js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
    <script src="<?= base_url('front-end/');?>assets/js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="<?= base_url('front-end/');?>assets/js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
    <script src="<?= base_url('front-end/');?>assets/js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
    <script src="<?= base_url('front-end/');?>assets/js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
    <script src="<?= base_url('front-end/');?>assets/js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>