<?php
class M_pengalaman extends CI_Model{

	function get_karakofolio_home(){
		$hsl=$this->db->query("SELECT tbl_pengalaman.*,DATE_FORMAT(pengal_tanggal,'%d %M %Y') AS tanggal FROM tbl_pengalaman ORDER BY pengal_id DESC limit 8");
		return $hsl;
	}

	function get_all_pengalaman(){
		$hsl=$this->db->query("SELECT tbl_pengalaman.*,DATE_FORMAT(pengal_tanggal,'%d %M %Y') AS tanggal FROM tbl_pengalaman ORDER BY pengal_id DESC");
		return $hsl;
	} 
	
	function simpan_pengalaman($judul,$isi,$user_nama,$gambar){
		$hsl=$this->db->query("INSERT INTO tbl_pengalaman (pengal_judul,pengal_deskripsi,pengal_author,pengal_image) VALUES ('$judul','$isi','$user_nama','$gambar')");
		return $hsl;
	}

	function get_pengalaman_by_kode($kode){
		$hsl=$this->db->query("SELECT * FROM tbl_pengalaman WHERE pengal_id='$kode'");
		return $hsl;
	}

	function update_pengalaman($pengal_id,$judul,$isi,$user_nama,$gambar){
		$hsl=$this->db->query("UPDATE tbl_pengalaman SET pengal_judul='$judul',pengal_deskripsi='$isi',pengal_author='$user_nama',pengal_image='$gambar' WHERE pengal_id='$pengal_id'");
		return $hsl;
	}

	function update_pengalaman_tanpa_img($pengal_id,$judul,$isi,$user_nama){
		$hsl=$this->db->query("UPDATE tbl_pengalaman SET pengal_judul='$judul',pengal_deskripsi='$isi',pengal_author='$user_nama' WHERE pengal_id='$pengal_id'");
		return $hsl;
	}

	function hapus_pengalaman($kode){
		$hsl=$this->db->query("DELETE FROM tbl_pengalaman WHERE pengal_id='$kode'");
		return $hsl;
	}


	//Frontend
	function get_pengalaman(){
		$hsl=$this->db->query("SELECT tbl_pengalaman.*,DATE_FORMAT(pengal_tanggal,'%d %M %Y') AS tanggal FROM tbl_pengalaman ORDER BY pengal_id DESC");
		return $hsl;
	}

	function get_pengalaman_per_page($offset,$limit){
		$hsl=$this->db->query("SELECT tbl_pengalaman.*,DATE_FORMAT(pengal_tanggal,'%d %M %Y') AS tanggal FROM tbl_pengalaman ORDER BY pengal_id DESC LIMIT $offset,$limit");
		return $hsl;
	}
}