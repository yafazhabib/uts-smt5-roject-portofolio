<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="">Yafaz Habib </a>.</strong> All rights reserved.
  </footer>