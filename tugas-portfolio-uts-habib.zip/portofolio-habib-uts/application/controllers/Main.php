<?php

class Main extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('m_portfolio');
		$this->load->model('m_karakter');
		$this->load->model('m_pendidikan');
		$this->load->model('m_pengalaman');
		$this->load->model('m_hobi');

		$this->load->library('upload');
	}

	public function index()
	{
		$x['data']=$this->m_portfolio->get_all_portfolio();
		$this->load->view('template/main_header');
		$this->load->view('template/main_navbar');
		$this->load->view('main/index',$x);
		
	}

	public function karakter()
	{
		$x['data']=$this->m_karakter->get_all_karakter();
		$this->load->view('template/main_header');
		$this->load->view('template/main_navbar');
		$this->load->view('main/karakter',$x);
		
	}
	public function pendidikan()
	{
		$x['data']=$this->m_pendidikan->get_all_pendidikan();
		$this->load->view('template/main_header');
		$this->load->view('template/main_navbar');
		$this->load->view('main/pendidikan',$x);
		
	}
	public function pengalaman()
	{
		$x['data']=$this->m_pengalaman->get_all_pengalaman();
		$this->load->view('template/main_header');
		$this->load->view('template/main_navbar');
		$this->load->view('main/pengalaman',$x);
		
	}
	public function hobi()
	{
		$x['data']=$this->m_hobi->get_all_hobi();
		$this->load->view('template/main_header');
		$this->load->view('template/main_navbar');
		$this->load->view('main/hobi',$x);
		
	}


	function success(){
		$this->load->view('v_success');
	}
}


?>
