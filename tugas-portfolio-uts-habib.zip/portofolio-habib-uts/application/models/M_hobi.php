<?php
class M_hobi extends CI_Model{

	function get_karakofolio_home(){
		$hsl=$this->db->query("SELECT tbl_hobi.*,DATE_FORMAT(hobi_tanggal,'%d %M %Y') AS tanggal FROM tbl_hobi ORDER BY hobi_id DESC limit 8");
		return $hsl;
	}

	function get_all_hobi(){
		$hsl=$this->db->query("SELECT tbl_hobi.*,DATE_FORMAT(hobi_tanggal,'%d %M %Y') AS tanggal FROM tbl_hobi ORDER BY hobi_id DESC");
		return $hsl;
	} 
	
	function simpan_hobi($judul,$isi,$user_nama,$gambar){
		$hsl=$this->db->query("INSERT INTO tbl_hobi (hobi_judul,hobi_deskripsi,hobi_author,hobi_image) VALUES ('$judul','$isi','$user_nama','$gambar')");
		return $hsl;
	}

	function get_hobi_by_kode($kode){
		$hsl=$this->db->query("SELECT * FROM tbl_hobi WHERE hobi_id='$kode'");
		return $hsl;
	}

	function update_hobi($hobi_id,$judul,$isi,$user_nama,$gambar){
		$hsl=$this->db->query("UPDATE tbl_hobi SET hobi_judul='$judul',hobi_deskripsi='$isi',hobi_author='$user_nama',hobi_image='$gambar' WHERE hobi_id='$hobi_id'");
		return $hsl;
	}

	function update_hobi_tanpa_img($hobi_id,$judul,$isi,$user_nama){
		$hsl=$this->db->query("UPDATE tbl_hobi SET hobi_judul='$judul',hobi_deskripsi='$isi',hobi_author='$user_nama' WHERE hobi_id='$hobi_id'");
		return $hsl;
	}

	function hapus_hobi($kode){
		$hsl=$this->db->query("DELETE FROM tbl_hobi WHERE hobi_id='$kode'");
		return $hsl;
	}


	//Frontend
	function get_hobi(){
		$hsl=$this->db->query("SELECT tbl_hobi.*,DATE_FORMAT(hobi_tanggal,'%d %M %Y') AS tanggal FROM tbl_hobi ORDER BY hobi_id DESC");
		return $hsl;
	}

	function get_hobi_per_page($offset,$limit){
		$hsl=$this->db->query("SELECT tbl_hobi.*,DATE_FORMAT(hobi_tanggal,'%d %M %Y') AS tanggal FROM tbl_hobi ORDER BY hobi_id DESC LIMIT $offset,$limit");
		return $hsl;
	}
}