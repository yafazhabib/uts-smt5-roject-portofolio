    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
                <!-- Text Logo - Use this if you don't have a graphic logo -->
                <!-- <a class="navbar-brand logo-text page-scroll" href="index.html">Evolo</a> -->
                <!-- Image Logo -->
                <!-- <a class="navbar-brand logo-image" href="#"><img src="<?= base_url('front-end/');?>assets/images/blackexpo2.png" alt="logoheader" style="
            width: 110px;
            height: 55px;
        "></a> -->
		
        <!-- Mobile Menu Toggle Button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-awesome fas fa-bars"></span>
            <span class="navbar-toggler-awesome fas fa-times"></span>
        </button>
        <!-- end of mobile menu toggle button -->
    <!-- Dropdown Menu -->  
        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link page-scroll" href="<?= base_url('main/');?>">Profil <span class="sr-only">(current)</span></a>
                </li>
				<li class="nav-item">
                    <a class="nav-link page-scroll" href="<?= base_url('main/karakter');?>" >Tentang<span class="sr-only">(current)</span></a>
                </li>
				<li class="nav-item">
                    <a class="nav-link page-scroll" href="<?= base_url('main/pendidikan');?>" >Pendidikan<span class="sr-only">(current)</span></a>
                </li>
				<li class="nav-item">
                    <a class="nav-link page-scroll" href="<?= base_url('main/pengalaman');?>" >Pengalaman Kerja<span class="sr-only">(current)</span></a>
				<li class="nav-item">
                    <a class="nav-link page-scroll" href="<?= base_url('main/hobi');?>" >Hobi<span class="sr-only">(current)</span></a>
                </li>
                  
                </div>               
        <!-- end of dropdown menu -->
            </ul>
        
        </div>
    </nav> <!-- end of navbar -->
    <!-- end of navigation -->

    <!-- End Navigation -->
